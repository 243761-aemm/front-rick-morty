/** @type {import('next').NextConfig} */
const nextConfig = {
  // Necesario para que el Dockerfile multistage funcione:
  // genera un servidor Node.js autónomo en .next/standalone
  output: 'standalone',
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'rickandmortyapi.com',
        pathname: '/**',
      },
    ],
  },
}

module.exports = nextConfig
