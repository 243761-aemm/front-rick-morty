import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './src/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      fontFamily: {
        display: ['var(--font-display)', 'sans-serif'],
        body: ['var(--font-body)', 'monospace'],
      },
      colors: {
        'dark-bg':   '#0d1117',
        'dark-card': '#1a1f2e',
        'dark-deep': '#141923',
      },
    },
  },
  plugins: [],
}
export default config
