'use client';
import { useState } from 'react';
import type { CharacterFilters } from '../services/types';

interface FiltersPanelProps {
  filters: CharacterFilters;
  onChange: (filters: CharacterFilters) => void;
}

export default function FiltersPanel({ filters, onChange }: FiltersPanelProps) {
  const [name, setName] = useState(filters.name || '');

  const handleSearch = () => {
    onChange({ ...filters, name, page: 1 });
  };

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleSearch();
  };

  const handleStatus = (status: string) => {
    onChange({ ...filters, status: filters.status === status ? '' : status, page: 1 });
  };

  const handleClear = () => {
    setName('');
    onChange({ page: 1 });
  };

  const statuses = ['Alive', 'Dead', 'unknown'];
  const statusLabels: Record<string, string> = { Alive: 'Vivo', Dead: 'Muerto', unknown: 'Desconocido' };

  return (
    <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center flex-wrap">
      {/* Search input */}
      <div className="relative flex-1 max-w-sm">
        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm" style={{ color: '#6b7280' }}>🔍</span>
        <input
          type="text"
          value={name}
          onChange={e => setName(e.target.value)}
          onKeyDown={handleKey}
          placeholder="Buscar personaje..."
          className="w-full pl-9 pr-4 py-2.5 rounded-xl text-white text-sm focus:outline-none transition-colors"
          style={{
            backgroundColor: 'rgba(255,255,255,0.05)',
            border: '1px solid rgba(255,255,255,0.1)',
            color: '#e2e8f0',
          }}
          onFocus={e => (e.currentTarget.style.borderColor = 'rgba(34,197,94,0.5)')}
          onBlur={e => (e.currentTarget.style.borderColor = 'rgba(255,255,255,0.1)')}
        />
      </div>

      <button
        onClick={handleSearch}
        className="px-4 py-2.5 rounded-xl text-sm font-semibold transition-all"
        style={{
          backgroundColor: 'rgba(34,197,94,0.2)',
          border: '1px solid rgba(34,197,94,0.3)',
          color: '#86efac',
        }}
        onMouseEnter={e => (e.currentTarget.style.backgroundColor = 'rgba(34,197,94,0.3)')}
        onMouseLeave={e => (e.currentTarget.style.backgroundColor = 'rgba(34,197,94,0.2)')}
      >
        Buscar
      </button>

      {/* Status filters */}
      <div className="flex gap-2 flex-wrap">
        {statuses.map(s => (
          <button
            key={s}
            onClick={() => handleStatus(s)}
            className="px-3 py-1.5 rounded-full text-xs font-semibold transition-all"
            style={filters.status === s ? {
              backgroundColor: 'rgba(34,197,94,0.3)',
              border: '1px solid rgba(34,197,94,0.5)',
              color: '#86efac',
            } : {
              backgroundColor: 'rgba(255,255,255,0.05)',
              border: '1px solid rgba(255,255,255,0.1)',
              color: '#9ca3af',
            }}
          >
            {statusLabels[s]}
          </button>
        ))}
      </div>

      {/* Clear */}
      {(filters.name || filters.status) && (
        <button
          onClick={handleClear}
          className="text-xs underline underline-offset-2 transition-colors"
          style={{ color: '#6b7280' }}
          onMouseEnter={e => (e.currentTarget.style.color = '#d1d5db')}
          onMouseLeave={e => (e.currentTarget.style.color = '#6b7280')}
        >
          Limpiar
        </button>
      )}
    </div>
  );
}
