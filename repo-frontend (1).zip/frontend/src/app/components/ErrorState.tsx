'use client';

interface ErrorStateProps {
  message?: string;
  onRetry?: () => void;
}

export default function ErrorState({ message, onRetry }: ErrorStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-24 text-center">
      <div className="relative w-24 h-24 mb-6">
        <div className="absolute inset-0 rounded-full animate-ping" style={{ backgroundColor: 'rgba(34,197,94,0.2)' }} />
        <div className="relative w-24 h-24 rounded-full flex items-center justify-center" style={{ backgroundColor: '#1a1f2e', border: '2px solid rgba(34,197,94,0.4)' }}>
          <span className="text-4xl">☠️</span>
        </div>
      </div>
      <h3 className="text-2xl font-bold text-white mb-2">
        ¡Dimensión equivocada!
      </h3>
      <p className="mb-6 max-w-xs" style={{ color: '#9ca3af' }}>
        {message || 'No se pudo conectar con el Consejo de Ricks. Intenta de nuevo.'}
      </p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="px-6 py-2.5 rounded-xl font-semibold transition-all"
          style={{
            backgroundColor: 'rgba(34,197,94,0.2)',
            border: '1px solid rgba(34,197,94,0.4)',
            color: '#86efac',
          }}
          onMouseEnter={e => (e.currentTarget.style.backgroundColor = 'rgba(34,197,94,0.3)')}
          onMouseLeave={e => (e.currentTarget.style.backgroundColor = 'rgba(34,197,94,0.2)')}
        >
          Abrir portal de nuevo
        </button>
      )}
    </div>
  );
}
