'use client';

export function CharacterCardSkeleton() {
  return (
    <div className="rounded-2xl overflow-hidden animate-pulse" style={{ backgroundColor: '#1a1f2e', border: '1px solid rgba(255,255,255,0.05)' }}>
      <div className="w-full h-52" style={{ backgroundColor: 'rgba(255,255,255,0.1)' }} />
      <div className="p-4 space-y-3">
        <div className="h-5 rounded w-3/4" style={{ backgroundColor: 'rgba(255,255,255,0.1)' }} />
        <div className="h-3 rounded w-1/3" style={{ backgroundColor: 'rgba(255,255,255,0.1)' }} />
        <div className="h-3 rounded w-1/2" style={{ backgroundColor: 'rgba(255,255,255,0.1)' }} />
        <div className="h-3 rounded w-2/3" style={{ backgroundColor: 'rgba(255,255,255,0.1)' }} />
      </div>
    </div>
  );
}

export function SkeletonGrid({ count = 20 }: { count?: number }) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
      {Array.from({ length: count }).map((_, i) => (
        <CharacterCardSkeleton key={i} />
      ))}
    </div>
  );
}
