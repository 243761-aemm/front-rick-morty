'use client';
import Image from 'next/image';
import { useEffect } from 'react';
import type { Character } from '../services/types';
import StatusBadge from './StatusBadge';

interface CharacterModalProps {
  character: Character | null;
  onClose: () => void;
}

export default function CharacterModal({ character, onClose }: CharacterModalProps) {
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', handleKey);
    return () => document.removeEventListener('keydown', handleKey);
  }, [onClose]);

  if (!character) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ backgroundColor: 'rgba(0,0,0,0.7)', backdropFilter: 'blur(4px)' }}
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-md rounded-3xl overflow-hidden animate-in"
        style={{
          backgroundColor: '#141923',
          border: '1px solid rgba(34,197,94,0.2)',
          boxShadow: '0 25px 50px rgba(34,197,94,0.1)',
        }}
        onClick={e => e.stopPropagation()}
      >
        {/* Close */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 w-8 h-8 rounded-full flex items-center justify-center transition-colors text-gray-400 hover:text-white"
          style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}
        >
          ✕
        </button>

        {/* Image */}
        <div className="relative h-64 w-full">
          <Image
            src={character.image}
            alt={character.name}
            fill
            className="object-cover"
            sizes="448px"
          />
          <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, #141923 0%, rgba(20,25,35,0.4) 50%, transparent 100%)' }} />
        </div>

        {/* Content */}
        <div className="px-6 pb-6 -mt-8 relative space-y-4">
          <div>
            <h2 className="text-2xl font-bold text-white mb-2">{character.name}</h2>
            <StatusBadge status={character.status} />
          </div>

          <div className="grid grid-cols-2 gap-3">
            {[
              { label: 'Especie',  value: character.species },
              { label: 'Género',   value: character.gender },
              { label: 'Tipo',     value: character.type || 'N/A' },
              { label: 'Origen',   value: character.origin.name },
              { label: 'Ubicación actual', value: character.location.name },
              { label: 'Episodios', value: `${character.episode.length} apariciones` },
            ].map(({ label, value }) => (
              <div key={label} className="rounded-xl p-3" style={{ backgroundColor: 'rgba(255,255,255,0.05)' }}>
                <p className="text-xs mb-0.5" style={{ color: '#6b7280' }}>{label}</p>
                <p className="text-sm text-white font-medium line-clamp-2">{value}</p>
              </div>
            ))}
          </div>

          <p className="text-xs text-center font-mono" style={{ color: '#4b5563' }}>
            ID #{character.id} · Creado: {new Date(character.created).toLocaleDateString('es-MX')}
          </p>
        </div>
      </div>
    </div>
  );
}
