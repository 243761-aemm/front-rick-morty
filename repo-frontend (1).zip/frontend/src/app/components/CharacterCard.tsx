'use client';
import Image from 'next/image';
import { useState } from 'react';
import type { Character } from '../services/types';
import StatusBadge from './StatusBadge';

interface CharacterCardProps {
  character: Character;
  onClick?: (character: Character) => void;
}

export default function CharacterCard({ character, onClick }: CharacterCardProps) {
  const [imgError, setImgError] = useState(false);

  return (
    <div
      onClick={() => onClick?.(character)}
      className="group cursor-pointer rounded-2xl overflow-hidden border transition-all duration-300 hover:scale-[1.02] hover:shadow-xl"
      style={{
        backgroundColor: '#1a1f2e',
        borderColor: 'rgba(255,255,255,0.05)',
        boxShadow: undefined,
      }}
      onMouseEnter={e => (e.currentTarget.style.borderColor = 'rgba(34,197,94,0.4)')}
      onMouseLeave={e => (e.currentTarget.style.borderColor = 'rgba(255,255,255,0.05)')}
    >
      {/* Image */}
      <div className="relative w-full h-52 overflow-hidden" style={{ backgroundColor: '#0d1117' }}>
        {!imgError ? (
          <Image
            src={character.image}
            alt={character.name}
            fill
            className="object-cover group-hover:scale-105 transition-transform duration-500"
            onError={() => setImgError(true)}
            sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 20vw"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-5xl">👾</div>
        )}
        <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, #1a1f2e, transparent)' }} />
      </div>

      {/* Info */}
      <div className="p-4 space-y-2">
        <h3 className="font-bold text-white text-sm leading-tight line-clamp-1 group-hover:text-green-300 transition-colors">
          {character.name}
        </h3>
        <StatusBadge status={character.status} />
        <div className="text-xs space-y-0.5 pt-1" style={{ color: '#6b7280' }}>
          <p><span style={{ color: '#4b5563' }}>Especie:</span> {character.species}</p>
          <p className="line-clamp-1"><span style={{ color: '#4b5563' }}>Ubicación:</span> {character.location.name}</p>
        </div>
        <p className="text-xs font-mono" style={{ color: 'rgba(34,197,94,0.6)' }}>#{character.id}</p>
      </div>
    </div>
  );
}
